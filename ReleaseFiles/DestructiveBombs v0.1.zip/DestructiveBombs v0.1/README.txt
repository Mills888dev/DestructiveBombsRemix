Destructive Bombs by Slime_Cubed

 -- DESCRIPTION --
Explosives damage terrain.

 -- NOTES --
This mod supports ConfigMachine. Go to the mod config screen to change the radius of explosions.
Message me on Discord (Slime_Cubed#5880) when something goes wrong, I'll try to fix it.
Before that, however, make sure you're using the current version of the mod.

 -- CHANGES --
v0.1:
 - Initial release